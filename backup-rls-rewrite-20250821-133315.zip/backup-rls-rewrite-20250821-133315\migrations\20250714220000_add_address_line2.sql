-- Add address_line2 to master_agencies
ALTER TABLE master_agencies ADD COLUMN address_line2 text; 